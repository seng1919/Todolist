from django.urls import path
from .views import * # import all functions in views.py
urlpatterns = [
    path('', Home),
    path('api/all-todolist/',all_todolist),  # localhost:8080/api/all-todolist
    path('api/post-todolist',post_todolist),  # localhost:8080/api/post-todolist
    path('api/update-todolist/<int:TID>',update_todolist),   # localhost:8080/api/update-todolist/3
    path('api/delete-todolist/<int:TID>',delete_todolist)   # localhost:8080/api/delete-todolist/3
]