# Import django & http
from django.shortcuts import render
from django.http import JsonResponse

# Import REST framework
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from .serializers import TodolistSerializers

# Import Model (Database)
from .models import Todolist

# Get Data
@api_view(['GET'])
def all_todolist(request):
    alltodolist = Todolist.objects.all() # Pull data (select *) from Todolist model
    serializer = TodolistSerializers(alltodolist,many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)


# Post Data (save data to database)
@api_view(['POST'])
def post_todolist(request):
    if request.method == 'POST':
        serializer = TodolistSerializers(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_404_NOT_FOUND)


# Put Data (Update Data)
@api_view(['PUT'])
def update_todolist(request,TID):
    # localhost:8000/api/update-todolist/TID
    todo = Todolist.objects.get(id=TID)

    if request.method == 'PUT':
        data = {}
        serializer = TodolistSerializers(todo,data=request.data)
        if serializer.is_valid():
            serializer.save()
            data['status'] = 'updated'
            return Response(data=data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_404_NOT_FOUND)


# Delete Data
@api_view(['DELETE'])
def delete_todolist(request,TID):
    todo = Todolist.objects.get(id=TID)

    if request.method == 'DELETE':
        delete = todo.delete()
        data = {}
        if delete:
            data['status'] = 'deleted'
            statuscode = status.HTTP_200_OK
        else:
            data['status'] = 'failed'
            statuscode = status.HTTP_400_BAD_REQUEST
        return Response(data=data, status=statuscode)

data = [
    {
        "title" : "French Bulldog",
        "subtitle" : "French bulldog (เฟรนช์ บูลด็อก) เป็นสุนัขพันธุ์เล็ก ต้นกำเนิดมาจากการผสมพันธุ์ของ English bulldog กับ Boston Terriers โดย..",
        "URL" : "https://raw.githubusercontent.com/seng1919/BasicAPI/main/bulldog.jpeg",
        "detail" : "French bulldog (เฟรนช์ บูลด็อก) เป็นสุนัขพันธุ์เล็ก ต้นกำเนิดมาจากการผสมพันธุ์ของ English bulldog กับ Boston Terriers โดยการตั้งชื่อพันธุ์คำว่า French หมายถึงประเทศฝรั่งเศส ถือเป็นแหล่งกำเนิดของเฟรนช์ บูลด็อกแต่เนื่องจากคนในสหรัฐอเมริกา และประเทศอังกฤษ มักนิยมเลี้ยงสุนัขพันธุ์เฟรนช์ บูลด็อกทำให้ในต่อมาถูกนิมยมเรียกสุนัขพันธุ์ เฟรนช์ บูลด็อกเป็น Frenchie (เฟรนช์ชี่) และมีชื่อเล่น คือ Clown dogs เพราะมีความขี้เล่นคล้ายตัวตลก หรือ Frog dogs เพราะตอนนั่งขาหลังของสุนัขจะกางออก"
    },
    {
        "title" : "Beagle",
        "subtitle" : "บีเกิล เป็นสายพันธุ์สุนัขมีถิ่นกำเนิดในประเทศสหราชอาณาจักร อยู่ในจำพวกกลุ่มสุนัขล่าเนื้อ มีขนสั้นและหูปรก เป็นสุนัขที่มีประสาทด้านการดมกลิ่นเป็นเลิศ..",
        "URL" : "https://raw.githubusercontent.com/seng1919/BasicAPI/main/beagle.jpeg",
        "detail" : "บีเกิ้ล (Beagle) เป็นสายพันธุ์สุนัขมีถิ่นกำเนิดในประเทศสหราชอาณาจักร อยู่ในจำพวกกลุ่มสุนัขล่าเนื้อ (Hound) มีขนสั้นและหูปรก เป็นสุนัขที่มีประสาทด้านการดมกลิ่นเป็นเลิศ (scent hounds) ที่พัฒนาสายพันธุ์ขึ้นมาครั้งแรก ด้วยจุดประสงค์เพื่อเป็นผู้ช่วยมนุษย์ ในกีฬาการล่าต่างๆ โดยเฉพาะการล่ากระต่าย ด้วยประสาทด้านการดมกลิ่นที่ไวมาก จึงได้มีการฝึกให้เป็นสุนัขตรวจสอบของผิดกฎหมาย อย่างเช่น ยาเสพติด วัตถุระเบิด ฯลฯ แต่บีเกิ้ลยังได้รับความนิยมในฐานะสัตว์เลี้ยงเช่นกัน ด้วยขนาดตัวที่พอเหมาะ เป็นสุนัขอารมณ์ดี และสุขภาพแข็งแรงทนทานต่อโรค ด้วยคุณสมบัตินี้เอง บีเกิ้ลยังถูกใช้ในงานวิจัยต่างๆ ที่เกี่ยวกับสัตว์อีกด้วย"
    },
    {
        "title" : "Pembroke Welsh Corgi",
        "subtitle" : "พ็อมโบรค เวล์ช คอร์กี้เป็นที่รู้จักอย่างกว้างขวางในเรื่องของความฉลาด ห้าวหาญ และกระตือรือล้น เข้มแข็งและต้องการเป็นส่วนหนึ่งของครอบครัว..",
        "URL" : "https://raw.githubusercontent.com/seng1919/BasicAPI/main/corgi.jpeg",
        "detail" : "พ็อมโบรค เวล์ช คอร์กี้เป็นที่รู้จักอย่างกว้างขวางในเรื่องของความฉลาด ห้าวหาญ และกระตือรือล้น ร่าเริงไม่ต้องการที่จะอยู่นิ่งๆ ในความคิดของพวกเขา พวกเขาเป็นหมาใหญ่ในร่างเล็ก \n\nสุนัขพันธุ์นี้สามารถจัดการต้อนปศุสัตว์ที่ตัวใหญ่กว่าได้ จากความรวดเร็วว่องไว ขบ และ เปลี่ยนทิศทางได้อย่างคล่องแคล่ว ซึ่งจากสายเลือดของความเป็นสุนัขในฟาร์ม จึงไม่แปลกในว่านิสัยนี้จะติดตัวมาในการล่าสัตว์เล็กๆ เช่น หนู แมลง เฝ้าบ้าน ต้อนปศุสัตว์ คอร์กี้ต้องการการออกกำลังกายและฝึกฝนอย่างสม่ำเสมอ ด้วยความรักและเมตตาเพื่อสามารถดึงพรสวรรค์ของเขาออกมาได้อย่างเต็มที่ \n\nคอร์กี้ อาจมีพฤติกรรมก้าวร้าว เช่น เห่า ขุด หรือ กัดแทะ เมื่อถูกต้องให้อยู่ตามลำพังมากเกินไป หรือว่าไม่ได้รับการออกกำลังกายที่เพียงพอ เขาต้องการเป็นส่วนหนึ่งของครอบครัวและไม่ควรทิ่งไว้ในบ้านสุนัขมากเกินไป คอร์กี้จะอาศัยร่วมกับสัตว์เลี้ยงตัวอื่นหรือเด็กๆ ที่ถูกเลี่ยงมาพร้อมกับมันได้ แต่พึงระลึกไว้เสมอว่าบางครั้นมันอาจจะวิ่งไล่หรือขบที่ขาของเด็กๆ ที่กำลังวิ่งได้ จากสัญชาตญาณการต้อนสัตว์ของเขา"
    },
    {
        "title" : "Shiba Inu",
        "subtitle" : "นิสัยที่โดดเด่นของสุนัขพันธุ์ชิบะ อินุ คือ ความกล้าหาญ กระตือรือร้น ซื่อสัตย์ รักอิสระ เพราะสุนัขพันธุ์นี้มักจะมีชีวิตชีวาเมื่อ..",
        "URL" : "https://raw.githubusercontent.com/seng1919/BasicAPI/main/shiba.jpeg",
        "detail" : "นิสัยที่โดดเด่นของสุนัขพันธุ์ชิบะ อินุ คือ ความกล้าหาญ กระตือรือร้น ซื่อสัตย์ รักอิสระ เพราะสุนัขพันธุ์นี้มักจะมีชีวิตชีวาเมื่ออยู่นอกบ้าน และสงบเรียบร้อยเมื่ออยู่ในบ้าน ชอบวิ่งเล่น ทำกิจกรรม และผจญภัยมาก อีกทั้งชิบะบางตัวยังมีความมั่นใจสูง มีความคิดเป็นของตัวเอง และไม่ชอบถูกควบคุม แต่ถึงอย่างนั้นหมาชิบะก็รักเจ้าของมากที่สุด แถมยังหวงข้าวของมาก จนทำให้เข้ากับคนแปลกหน้าและสัตว์ตัวอื่นได้ไม่ดีเท่าไร รวมถึงชอบไล่ล่าสัตว์ตัวเล็กด้วย"
    },
    {
        "title" : "Chihuahua",
        "subtitle" : "ชิวาวาเป็นสุนัขที่รักและชอบใกล้ชิดกับผู้คน ถึงแม้ว่าพวกมันจะมีขนาดตัวที่เล็กแต่พวกมันมีนิสัยที่ตื่นตัวจึงทำให้สามารถเป็นสุนัขเฝ้าบ้านที่ยอดเยี่ยมได้..",
        "URL" : "https://raw.githubusercontent.com/seng1919/BasicAPI/main/chihuahua.jpeg",
        "detail" : "ชิวาวาเป็นสุนัขที่รักและชอบใกล้ชิดกับผู้คน ถึงแม้ว่าพวกมันจะมีขนาดตัวที่เล็กแต่พวกมันมีนิสัยที่ตื่นตัวจึงทำให้สามารถเป็นสุนัขเฝ้าบ้านที่ยอดเยี่ยมได้\n\nชิวาวาเป็นสุนัขสายพันธุ์ที่ฉลาดซึ่งสามารถทำการฝึกอบรมได้โดยใช้ความอดทน พวกมันจำเป็นต้องได้รับการกระตุ้นทางทางความคิดบ่อยที่สุดเท่าที่จะทำได้ โดยรวมแล้วสุนัขสายพันธุ์นี้ต้องการความรักและเป็นสัตว์เลี้ยงที่ยอดเยี่ยมสำหรับทุกครอบครัว"
    }
]

def Home(request):
    return JsonResponse(data=data,safe=False,json_dumps_params={'ensure_ascii': False})